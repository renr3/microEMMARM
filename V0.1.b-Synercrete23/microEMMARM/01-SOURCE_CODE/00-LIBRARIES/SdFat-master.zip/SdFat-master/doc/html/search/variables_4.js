var searchData=
[
  ['dec_0',['dec',['../classios__base.html#a2826aed005e7c1f6858060cddae7971a',1,'ios_base']]],
  ['dedicated_5fspi_1',['DEDICATED_SPI',['../_sd_spi_driver_8h.html#ad81ddcc2265c6b6a4c835fd739f0f534',1,'SdSpiDriver.h']]]
];
