var searchData=
[
  ['read_5fstate_0',['READ_STATE',['../class_shared_spi_card.html#a4343d76001e1bc7f2839437cc85e8485',1,'SharedSpiCard']]],
  ['reserved_1',['reserved',['../struct_c_i_d.html#a7d489455802a3a9728a5cec60927a7c7',1,'CID']]],
  ['right_2',['right',['../classios__base.html#aec064a12730b5d87e718c1864e29ac64',1,'ios_base']]]
];
