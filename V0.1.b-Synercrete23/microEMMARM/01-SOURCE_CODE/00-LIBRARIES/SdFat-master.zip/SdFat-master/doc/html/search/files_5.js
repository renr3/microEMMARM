var searchData=
[
  ['minimumserial_2eh_0',['MinimumSerial.h',['../_minimum_serial_8h.html',1,'']]]
];
