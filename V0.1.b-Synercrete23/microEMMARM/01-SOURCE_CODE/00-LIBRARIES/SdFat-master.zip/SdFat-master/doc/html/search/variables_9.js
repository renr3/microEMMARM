var searchData=
[
  ['idle_5fstate_0',['IDLE_STATE',['../class_shared_spi_card.html#a63fd0b86d2e248e43409e3e6743466fe',1,'SharedSpiCard']]],
  ['in_1',['in',['../classios__base.html#ae5432e3c269064480652c4602f5f74ad',1,'ios_base']]],
  ['internal_2',['internal',['../classios__base.html#afc720b7f6f461ec8e9cf5505059e5d7c',1,'ios_base']]],
  ['iscontiguous_3',['isContiguous',['../struct_dir_pos__t.html#a7bea047144551b24c5aa301dc8dd44d7',1,'DirPos_t']]]
];
