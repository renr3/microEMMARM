var searchData=
[
  ['ungetc_5fbuf_5fsize_0',['UNGETC_BUF_SIZE',['../_stdio_stream_8h.html#a785dd413c0d7b05f95df82d3453ecacd',1,'StdioStream.h']]],
  ['uppercase_1',['uppercase',['../classios__base.html#ade3db1fe3249e87f4c47a9a8916793d9',1,'ios_base']]]
];
